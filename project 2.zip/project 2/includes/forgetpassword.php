<?php
include 'core/init.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<title>be advisor</title>
<LINK REL=StyleSheet HREF="css/theme1.css" TITLE="Contemporary">
   </head>

<body>
    <div class="image">

<div class="headerx">
 </div>

 <div>
<div class="header">
<div id="logo" class="header"><img src="css/logo.png"/></div>

<!-- login  -->
   <?php include 'includes/login.php';?>

    </div>    
</div>

<div class="main">
 <center>

    <!-- sign in  -->
 <form>

<div class="box12">

 <div id="info12">"can't login  "</div><br>
 <div id="info22">enter the email id of your to come in </div>
 <br><br>

            <div>

                <div id="info32">EMAIL ID</div>
                <input type="text" name="emailid" class="form-control" style="width:350px; height:30px;"><br><br>
               
             </div>   

                

           <div class="form-group">
                <input type="submit" class="button2" value="find me">
            </div>
            </div>
            
       </form>
</center>
</div>

</body>
</html>








