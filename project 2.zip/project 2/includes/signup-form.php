<?php
if (isset ($_POST['signup'])){
	$email=$_POST['email'];
	$password=$_POST['password'];
	$username=$_POST['username'];
	$error='';


if(empty($username) or empty($email) or empty($password)){
	$error = 'all information are required';
	}
	 else {
	$email =  $getFromU->checkInput($email);
	$password =  $getFromU->checkInput($password);
	$username =  $getFromU->checkInput($username);
		
		if(!filter_var($email)){
	$error ='invalid email format';
		}
		else if(strlen($password)<5){
			$error='password is to short';
		}
		
		else{
			if($getFromU->checkEmail($email)===true){
				$error='email already exist';
			}
			else if(!empty($username)){
                if(strlen($username) > 20){
                    $error = "Username must be in between 6 to 20 characters";
                } 
                else if($getFromU->checkUsername($username) === true ){
                    $error = "username  already taken";
                }
			else{
				$getFromU->register($email,$username,$password);
			//$getFromU->create('users',array('email'=>$email,'password'=>md5($password),'username'=>$username,'profileImage' => 'images\defaultprofileimage.png'));

        $_SESSION['user_id'] = $user_id;


						header("location: home.php");					
							
					}
		}

				}
			}

		}
?>


<form method="post">
 <div class="form-group">

	<div id="info3">Name</div>
                <input type="text" name="username" style="width:350px; height:30px;"><br><br>
            </div>   

                <div class="form-group">
                <div id="info3" >Email Address</div>
                <input type="email" name="email" style="width:350px; height:30px;"/> <br><br>
            </div>  

            <div class="form-group">
                <div id="info3">Password</div>
                <input type="password" name="password" style="width:350px; height:30px;"/><br><br>
            </div>

            <div class="form-group">
           <input type="submit" name="signup" Value="Signup">
            </div>
	

	<?php
	if(isset($error)){
	echo'	
	 <div class="error-li">
	  <div class="span-fp-error">'.$error.'</div>
	 </div>'; 
	}
	?>
</div>
</form>