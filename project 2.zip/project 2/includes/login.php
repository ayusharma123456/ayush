<?php
if (isset($_POST['login']) && !empty($_POST['login'])){
	$email=$_POST['email'];
	$password=$_POST['password'];

if(!empty($email) or !empty($password)){
	$email = $getFromU -> checkInput($email);
	$password = $getFromU -> checkInput($password);
if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
	$error="invalid format";
}

else{
	if($getFromU->login($email, $password) === false){
		$error="the email or password is incorret";
	}

}


}else {
	$error="please enter the your shit to come bitch";
}



}

?>
<form method="post"> 
	<div id="form1" class="header">
<input type="text" name="email" style="height:25px; width:200px;" placeholder="email" value="">
            </div>  

 <div id="form2" class="header">
 <input type="password" style="height:25px; width:200px;" name="password"  placeholder="password"/>

</div>

<div id="submit1" class="header">

             <input type="submit" name="login" id="submit1" value="Log in"/>
            </div>

	<?php
	if(isset($error)){
		echo
	 ' <li class="error-li">
	  <div class="span-fp-error">'. $error .'</div>
	 </li> '; 
	}
	?>
	</form>
</div>


