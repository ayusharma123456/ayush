<?php
include 'core/init.php';
	$user_id = @$_SESSION['user_id'];
	$user = $getFromU->userData($user_id);
?>

<!DOCTYPE html>
<html>
<head>
<!-- javascript -->	
<script src="js\bootstrap.js"> </script>
<!-- css -->

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css\bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>css\style.css">
</head>

<body>

	<header>
		<div class="container-fluid">
			<div class="left_wrap">
				<a href="#" class="logo"><img src="./header/advsr.png"></a>

				<form>
			      <input type="text" placeholder="Search.." class="search">
			      <i class="fa fa-search" aria-hidden="true"></i>
					<div class="search-result">	</div>
			    </form>

			</div>
			<div>
			 <a href="<?php echo BASE_URL.$user->username;?>" class="user_name"><labelclass="drop-label" for="drop-wrap1"><img src="<?php echo BASE_URL.$user->profileImage;?>"/><?php echo $user->username;?></label></a>

				<button type="button" class="btn btn-success"><a href="<?php echo BASE_URL;?>home.php">advices</a></button>

			 	<a href="#"><i class="fa fa-star"></i></a>
			 	<a href="#"><i class="fa fa-ad"></i></a>
			 	<a href="#"> <i class="fa fa-user-friends"></i></a>
			 	<a href="#"><i class="fa fa-comment-alt"></i></a>

	 		 	<a href="<?php echo BASE_URL;?>"><i class="fa fa-bell"></i></a>

	 		 	<a href="#"><i class="fa fa-sort-desc"></i></a>
			</div>
			<div class="dropdown">
				<a href="<?php echo BASE_URL;?>settings">Settings</a>
				<a href="<?php echo BASE_URL;?>includes/logout.php">Log out</a>
			</div>
		</div>
	</header>
</body>
</html>