<?php

class Advice extends User{

    function __construct($pdo){
        $this->pdo = $pdo;
    }

}
?>