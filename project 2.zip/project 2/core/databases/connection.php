<?php
$dsn = "mysql:host=localhost;dbname=advisor3";
$user = "root";
$pass = "";


try {
    $pdo = new PDO($dsn, $user, $pass);



} catch (PDOException $e) {
    echo "Database is not connected!.. ".$e->getMessage();
}
?>