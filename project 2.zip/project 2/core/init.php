<?php
include 'databases/connection.php';
include 'classes/user.php';
include 'classes/follow.php';
include 'classes/advice.php';

global $pdo;

session_start();

$getFromU = new User($pdo);
$getFromF = new follow($pdo);
$getFromA = new advice($pdo);


define("BASE_URL", "http://localhost/project 2/");
?>