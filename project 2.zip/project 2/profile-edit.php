<?php
include 'header/header.php';
if($getFromU->loggedIn() === false){
	header("location: index.php");
}

if(isset($_POST['screenName'])){
    if(!empty($_POST['screenName'])){
        $screenName = $getFromU->checkInput($_POST['screenName']);
        $website = $getFromU->checkInput($_POST['website']);

        if(strlen($screenName) > 20){
            $error = "The name must be between 6 to 20 characters";
        } else{
            $getFromU->update('users', $user_id, array('screenName' => $screenName, 'bio' => $bio, 'country' => $country, 'website' => $website));
            header('location: '.$user->username);
        }
       
    }else{
        $error = "Name feild can't be blacnk";
    }
}

if(isset($_FILES['profileImage'])){
    if(!empty($_FILES['profileImage']['name'][0])){
        $fileRoot = $getFromU->uploadImage($_FILES['profileImage']);
        $getFromU->update('users', $user_id, array('profileImage' => $fileRoot));
        header('location: '.$user->username);
    }
}

?>

<!doctype html>
<html>
<head>
	<title>Profile edit page</title>
	<meta charset="UTF-8" />
	
</head>
<!--Helvetica Neue-->
<body>


<!--Profile cover-->

<div class="profile-nav">
	<div class="profile-navigation">
		<ul>
			
			<li>
				<a href="<?php echo BASE_URL.$user->username.'/following';?>">
					<div class="n-head">
						FOLLOWINGS
					</div>
					<div class="n-bottom">
						<?php echo $user->following; ?>
					</div>
				</a>
			</li>
			<li>
				<a href="<?php echo BASE_URL.$user->username.'/followers';?>">
					<div class="n-head">
						FOLLOWERS
					</div>
					<div class="n-bottom">
						<?php echo $user->followers; ?>
					</div>
				</a>
			</li>
			
			
		</ul>
		<div class="edit-button">
			<span>
				<button class="f-btn" type="button" onclick="window.location.href='<?php echo $user->username; ?>' " value="Cancel">Cancel</button>
			</span>
			<span>
				<input type="submit" id="save" value="Save Changes">
			</span>
		 
		</div>
	</div>
</div>
</div><!--Profile Cover End-->

<div class="in-wrapper">
<div class="in-full-wrap">
  <div class="in-left">
	<div class="in-left-wrap">
		<!--PROFILE INFO WRAPPER END-->
<div class="profile-info-wrap">
	<div class="profile-info-inner">
		<div class="profile-img">
			<!-- PROFILE-IMAGE -->
			<img src="<?php echo $user->profileImage; ?>"/>
 			<div class="img-upload-button-wrap1">
			 <div class="img-upload-button">
				<label for="img-upload-btn">
					<i class="fa fa-camera" aria-hidden="true"></i>
				</label>
				<span class="span-text">
					Change your profile photo
				</span>
				<input id="img-upload-btn" type="checkbox"/>
				<div class="img-upload-menu">
				 <span class="img-upload-arrow"></span>
					<form method="post" enctype="multipart/form-data">
						<ul>
							<li>
								<label for="profileImage">
									Upload photo
								</label>
								<input id="profileImage" type="file" onchange="this.form.submit();"  name="profileImage"/>
								
								
							</li>
							<li><a href="#">Remove</a></li>
							<li>
								<label for="img-upload-btn">
									Cancel
								</label>
							</li>
						</ul>
					</form>
				</div>
			  </div>
			  <!-- img upload end-->
			</div>
		</div>

			    <form id="editForm" method="post" enctype="multipart/Form-data">	
				<div class="profile-name-wrap">
                    <?php 
                    if(isset($imageError)){
                    echo '<ul>
	 					 <li class="error-li">
						 	 <div class="span-pe-error">'.$imageError.'</div>
						 </li>
					 </ul> ';
                     }
                     ?>

					<div class="profile-name">
						<input type="text" name="screenName" value="<?php echo $user->screenName; ?>"/>
					</div>
					<div class="profile-tname">
						@<?php echo $user->username; ?>
					</div>
				</div>
				
					<div class="profile-extra-info">
					<div class="profile-extra-inner">
						<ul>
							
							<li>
								<div class="profile-ex-location">
									<input type="text" name="website" placeholder="Website" value=""<?php echo $user->website; ?>"/>
								</div>
							</li>
				  <?php 
                    if(isset($error)){
                    echo '
	 					 <li class="error-li">
						 	 <div class="span-pe-error">'.$error.'</div>
						 </li>
					  ';
                     }
                     ?>
				</form>
                <script>
                    $('#save').click(function(){
                        $('#editForm').submit();
                    })
                </script>
						</ul>						
					</div>
				</div>
				<div class="profile-extra-footer">
					<div class="profile-extra-footer-head">
						<div class="profile-extra-info">
							<ul>
								<li>
									<div class="profile-ex-location-i">
										<i class="fa fa-camera" aria-hidden="true"></i>
									</div>
									<div class="profile-ex-location">
										<a href="#">0 Photos and videos </a>
									</div>
								</li>
							</ul>
						</div>
					</div>
					<div class="profile-extra-footer-body">
						<ul>
						  <!-- <li><img src="#"></li> -->
						</ul>
					</div>
				</div>
			</div>
			<!--PROFILE INFO INNER END-->
		</div>
		<!--PROFILE INFO WRAPPER END-->
	</div>
	<!-- in left wrap-->
</div>
<!-- in left end-->

<div class="in-center">
	<div class="in-center-wrap">	
		<!-- HERE WILL BE TWEETS -->
	</div>
	<!-- in left wrap-->
   <div class="popupTweet"></div>

</div>
<!-- in center end -->

<div class="in-right">
	<div class="in-right-wrap">
		<!--==WHO TO FOLLOW==-->
           <!-- HERE -->
		<!--==WHO TO FOLLOW==-->
			
		<!--==TRENDS==-->
 	 	   <!-- HERE -->
	 	<!--==TRENDS==-->
	</div>
	<!-- in left wrap-->
</div>
<!-- in right end -->

   </div>
   <!--in full wrap end-->
 
  </div>
  <!-- in wrappper ends-->

</div>
<!-- ends wrapper -->
</body>
</html>