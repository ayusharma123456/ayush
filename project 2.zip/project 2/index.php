<?php
include 'core/init.php';
if(isset($_SESSION['user_id'])){
    header("location: home.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<title>be advisor</title>
<LINK REL=StyleSheet HREF="css/theme.css" TITLE="Contemporary">
   </head>

<body>
    <div class="image">

<div class="headerx">
 </div>

 <div>
<div class="header">
<div id="logo" class="header"><img src="css/logo.png"/></div>

<!-- login  -->
   <?php include 'includes/login.php';?>
    </div> 
    <a href="includes/forgetpassword.php">forget password</a>
   
</div>

 
<div class="main">
 <center>

<div class="box">

 <div id="info1">"Give advice when they want to Take advice "</div><br>
 <div id="info2">Be Advisor</div>
    <?php include 'includes/signup-form.php';?>

 </center>
</div>
</div>
</body>
</html>